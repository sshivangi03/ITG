package com.file;

import java.util.Collection;
import java.io.Reader;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.file.data.LogEntry;
import com.file.util.FileParser;

public class DataFilterer{
	public static Collection<?> filterByCountry(Reader source, String country) {
		List<LogEntry> datalist = FileParser.readData(source);

		List<LogEntry> filteredData = datalist.stream()
				.filter(e -> e.getCountryCode().equals(country))
				.collect(Collectors.toList());
		return filteredData;
	}
	

	public static Collection<?> filterByCountryWithResponseTimeAboveLimit(Reader source, String country, long limit) {
		
		List<LogEntry> filteredData = ((List<LogEntry>) filterByCountry(source, country)).stream()
				.filter(e -> e.getResponseTime() > limit)
				.collect(Collectors.toList());
		
		return filteredData;
	}
	
	public static Collection<?> filterByResponseTimeAboveAverage(Reader source) {
		List<LogEntry> datalist = FileParser.readData(source);
		
		if(datalist.isEmpty()) {
			return Collections.emptyList();
		}
		
		double averageResponseTime = datalist.stream()
				.mapToLong(e -> e.getResponseTime())
				.average().getAsDouble();

		List<LogEntry> filteredData = datalist.stream()
				.filter(e -> e.getResponseTime() > averageResponseTime)
				.collect(Collectors.toList());
		return filteredData;
	}


}