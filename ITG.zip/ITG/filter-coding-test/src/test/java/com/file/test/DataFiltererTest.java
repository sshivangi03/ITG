package com.file.test;

import org.junit.Test;

import com.file.DataFilterer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import static org.junit.Assert.*;

public class DataFiltererTest {
    
    @Test
    public void filterByCountryCodeTest() throws FileNotFoundException {
    	assertEquals(DataFilterer.filterByCountry(openFile("src/test/resources/sample-extract"), "US").size(), 3);
    	assertEquals(DataFilterer.filterByCountry(openFile("src/test/resources/sample-extract"), "GB").size(), 1);
    	assertEquals(DataFilterer.filterByCountry(openFile("src/test/resources/sample-extract"), "DE").size(), 1);
    }
    
    @Test
    public void filterByCountryWithResponseTimeAboveLimit() throws FileNotFoundException {
    	assertEquals(DataFilterer.filterByCountryWithResponseTimeAboveLimit(openFile("src/test/resources/sample-extract"), "US", 100).size(), 3);
    	assertEquals(DataFilterer.filterByCountryWithResponseTimeAboveLimit(openFile("src/test/resources/sample-extract"), "US", 600).size(), 2);
    	assertEquals(DataFilterer.filterByCountryWithResponseTimeAboveLimit(openFile("src/test/resources/sample-extract"), "GB", 30).size(), 1);
    	assertTrue(DataFilterer.filterByCountryWithResponseTimeAboveLimit(openFile("src/test/resources/sample-extract"), "GB", 80).isEmpty());
    }
    
    @Test
    public void filterByResponseTimeAboveAverage() throws FileNotFoundException {
    	assertFalse(DataFilterer.filterByResponseTimeAboveAverage(openFile("src/test/resources/sample-extract")).isEmpty());
    	assertEquals(DataFilterer.filterByResponseTimeAboveAverage(openFile("src/test/resources/sample-extract")).size(), 3);
    }

    private FileReader openFile(String filename) throws FileNotFoundException {
        return new FileReader(new File(filename));
    }
}
